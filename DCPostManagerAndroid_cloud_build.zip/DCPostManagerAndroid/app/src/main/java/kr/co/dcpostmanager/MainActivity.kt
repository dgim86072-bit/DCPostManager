package kr.co.dcpostmanager

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject

data class PostItem(
    val gallery: String,
    val title: String,
    val body: String,
    val status: String = "미등록"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { PostManagerScreen() } }
    }
}

@Composable
fun PostManagerScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("dc_posts", Context.MODE_PRIVATE) }
    var posts by remember {
        mutableStateOf(loadPosts(prefs.getString("items", "[]") ?: "[]"))
    }
    var gallery by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("전체") }
    var notice by remember { mutableStateOf("") }

    fun save(next: List<PostItem>) {
        posts = next
        prefs.edit().putString("items", JSONArray().apply {
            next.forEach { p ->
                put(JSONObject().put("gallery", p.gallery).put("title", p.title)
                    .put("body", p.body).put("status", p.status))
            }
        }.toString()).apply()
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                val rows = parseCsv(text)
                val additions = rows.drop(1).mapNotNull { row ->
                    if (row.size >= 3 && row[0].isNotBlank() && row[1].isNotBlank())
                        PostItem(row[0].trim(), row[1].trim(), row.drop(2).joinToString(",").trim())
                    else null
                }
                val merged = (posts + additions).take(300)
                save(merged)
                notice = "${additions.size}개 행을 불러왔어. 최대 300개까지 관리할 수 있어."
            } catch (_: Exception) { notice = "파일을 읽지 못했어. UTF-8 CSV인지 확인해줘." }
        }
    }

    val visible = posts.withIndex().filter {
        filter == "전체" || it.value.status == filter
    }

    Scaffold(
        topBar = {
            TopAppBarCompat(
                title = "DC 게시글 매니저",
                subtitle = "최대 300개 · 기기 내부 저장"
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            Text("게시글 추가", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(gallery, { gallery = it }, label = { Text("갤러리명") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(title, { title = it }, label = { Text("제목") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(body, { body = it }, label = { Text("본문") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        if (gallery.isBlank() || title.isBlank() || body.isBlank()) notice = "갤러리명·제목·본문을 모두 입력해줘."
                        else if (posts.size >= 300) notice = "최대 300개까지 저장할 수 있어."
                        else {
                            save(posts + PostItem(gallery.trim(), title.trim(), body.trim()))
                            gallery = ""; title = ""; body = ""; notice = "게시글을 저장했어."
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("게시글 저장") }
                OutlinedButton(onClick = { importLauncher.launch(arrayOf("text/*", "application/csv")) }) {
                    Text("CSV 가져오기")
                }
            }
            if (notice.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(notice, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("저장된 게시글 ${posts.size}/300", fontWeight = FontWeight.Bold)
                TextButton(onClick = { filter = "전체" }) { Text("전체 보기") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("전체", "미등록", "작성 중", "등록 완료", "보류").forEach { f ->
                    FilterChip(selected = filter == f, onClick = { filter = f }, label = { Text(f) })
                }
            }
            Spacer(Modifier.height(8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(visible, key = { _, pair -> pair.index }) { _, pair ->
                    val index = pair.index
                    val post = pair.value
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text(post.gallery, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
                            Text(post.title, fontWeight = FontWeight.Bold)
                            Text(post.body, maxLines = 3, style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.height(8.dp))
                            Text("상태: ${post.status}", style = MaterialTheme.typography.labelMedium)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedButton(onClick = {
                                    copyText(context, post.title)
                                    notice = "제목을 클립보드에 복사했어."
                                }) { Text("제목 복사") }
                                OutlinedButton(onClick = {
                                    copyText(context, post.body)
                                    notice = "본문을 클립보드에 복사했어."
                                }) { Text("본문 복사") }
                                OutlinedButton(onClick = {
                                    val nextStatus = when (post.status) {
                                        "미등록" -> "작성 중"
                                        "작성 중" -> "등록 완료"
                                        "등록 완료" -> "보류"
                                        else -> "미등록"
                                    }
                                    save(posts.toMutableList().also { it[index] = post.copy(status = nextStatus) })
                                }) { Text("상태 변경") }
                            }
                            TextButton(onClick = {
                                save(posts.toMutableList().also { it.removeAt(index) })
                            }) { Text("삭제") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TopAppBarCompat(title: String, subtitle: String) {
    Surface(color = MaterialTheme.colorScheme.primaryContainer) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall)
        }
    }
}

fun copyText(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("DC post", text))
}

fun loadPosts(raw: String): List<PostItem> = try {
    val arr = JSONArray(raw)
    (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        PostItem(o.optString("gallery"), o.optString("title"), o.optString("body"), o.optString("status", "미등록"))
    }.take(300)
} catch (_: Exception) { emptyList() }

fun parseCsv(input: String): List<List<String>> {
    val rows = mutableListOf<List<String>>()
    var row = mutableListOf<String>()
    val field = StringBuilder()
    var quoted = false
    var i = 0
    while (i < input.length) {
        val c = input[i]
        when {
            c == '"' && quoted && i + 1 < input.length && input[i + 1] == '"' -> { field.append('"'); i++ }
            c == '"' -> quoted = !quoted
            c == ',' && !quoted -> { row.add(field.toString()); field.clear() }
            (c == '\n' || c == '\r') && !quoted -> {
                if (c == '\r' && i + 1 < input.length && input[i + 1] == '\n') i++
                row.add(field.toString()); field.clear()
                if (row.any { it.isNotBlank() }) rows.add(row)
                row = mutableListOf()
            }
            else -> field.append(c)
        }
        i++
    }
    row.add(field.toString())
    if (row.any { it.isNotBlank() }) rows.add(row)
    rows
}
