# DC 게시글 매니저 (Android)

삼성 갤럭시용 게시글 정리 앱 프로젝트입니다.

## 기능
- 게시글 최대 300개 로컬 저장
- 갤러리명 / 제목 / 본문 입력
- CSV 가져오기 (열 순서: 갤러리명, 제목, 본문)
- 제목 및 본문 클립보드 복사
- 미등록 / 작성 중 / 등록 완료 / 보류 상태 관리
- 필터링 및 개별 삭제

이 앱은 게시글을 디시인사이드에 자동 제출하지 않습니다. 게시글 등록은 사용자가 공식 앱/웹사이트에서 내용과 갤러리 규칙을 확인한 뒤 직접 진행해야 합니다.

## APK 빌드 방법
1. PC에 Android Studio 최신 안정 버전을 설치합니다.
2. 이 ZIP을 압축 해제하고 Android Studio에서 폴더를 엽니다.
3. SDK Platform 35 및 필요한 Gradle 구성요소 설치를 허용합니다.
4. 메뉴에서 Build > Build Bundle(s) / APK(s) > Build APK(s)를 선택합니다.
5. 생성된 APK를 삼성 갤럭시로 옮겨 설치합니다.

현재 실행 환경에는 Android SDK/Gradle 빌드 도구가 없어 APK 바이너리를 직접 컴파일하지 못합니다. 이 ZIP은 Android Studio에서 APK로 빌드할 수 있는 프로젝트 소스입니다.


## PC 없이 갤럭시에서 APK 만들기 (GitHub Actions)
1. GitHub 계정을 만들고 새 Repository를 생성합니다.
2. 이 프로젝트 ZIP의 압축을 풀고 파일과 `.github/workflows/build-apk.yml` 폴더를 포함해 저장소에 업로드합니다.
3. 저장소의 Actions 탭에서 `Build Android APK`를 선택하고 `Run workflow`를 누릅니다.
4. 빌드가 끝나면 실행 결과의 Artifacts에서 `DCPostManager-debug-apk`를 다운로드합니다.
5. ZIP을 풀어 `app-debug.apk`를 갤럭시에 설치합니다.

주의: 저장소는 Private으로 만드는 것을 권장합니다. APK는 디버그 빌드이며, 앱은 디시인사이드에 자동 제출하지 않습니다.
